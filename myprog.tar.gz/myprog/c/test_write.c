#include <stdlib.h>
#include <string.h>
#include <stdio.h>

int main()
{
    int number = 0x0506;
    char *tmpBuffer = malloc(4*sizeof(int));
    memset(tmpBuffer, 0x23, 4*sizeof(int));
    tmpBuffer[4*sizeof(int)-1]='\0';
    snprintf(tmpBuffer, sizeof(int), "%x", number);
    printf("%s\n", tmpBuffer);
}
