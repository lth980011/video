#include "stdio.h"
#include "stdlib.h"
#define DEVICES_PATH "ls /sys/bus/pci/devices"
int main()
{
    FILE *fp;
    char buf[200] = {0};
    //if((fp = popen("cat test", "r")) == NULL) {
    if((fp = popen(DEVICES_PATH, "r")) == NULL) {
        perror("Fail to popen\n");
        exit(1);
    }
    if(fread(buf, 1, sizeof(buf), fp) == 0)
    {

        printf("%s", buf);
    }
        printf("%s", buf);
#if 0
    while(fgets(buf, 200, fp) != NULL) {
        printf("%s", buf);
    }
#endif
    pclose(fp);
    return 0;
}
