#include <stdio.h>
#include <stdlib.h>

int main(){
    system("cat /proc/`(ps -A | grep -w vim |head -1| awk '{print $1}')`/status");
    system("free -lm");
}
