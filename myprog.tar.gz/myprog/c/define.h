/*
 * =====================================================================================
 *
 *       Filename:  define.h
 *
 *    Description:  
 *
 *        Version:  1.0
 *        Created:  05/29/2012 01:18:20 PM
 *       Revision:  none
 *       Compiler:  gcc
 *
 *         Author:  YOUR NAME (), 
 *   Organization:  
 *
 * =====================================================================================
 */

#define LOGE printf
