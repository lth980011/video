valgrind --tool=memcheck --leak-check=full --log-file=valgrind.log ./test_valgrind
