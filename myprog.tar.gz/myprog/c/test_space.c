#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main()
{
    char *str = malloc(256 * sizeof(char));
    char *tmpStr = NULL;
    strcpy(str, "1 2\t3\r4\n");
    int len = strlen(str);
    printf("len %d\n", len);
    tmpStr = str + len -1;
    for(; isspace(*tmpStr); tmpStr--)
    {
        if(isspace(*tmpStr))printf("space\n");
        else printf("%c\n", tmpStr[0]);
        //printf("%s\n", str);
    }
}
