
//#include <stdlib.h>
//#include <stdio.h>

#define LOGE printf
#define CHECK_CONTIDION(condition,str,ret) \
    if((condition)){\
        LOGE("%s: %s\n", __FUNCTION__, (str));\
        return ret;\
    }
#define CHECK_NULL(p,str, ret) CHECK_CONTIDION(NULL==(p),str,ret)
