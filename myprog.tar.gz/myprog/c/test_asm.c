#include <stdio.h>

int main(void) {
    long eax=4;
    long ebx=2;

    __asm__ __volatile__ ("add %1, %0"
            : "=b"((long)ebx)
            : "a"((long)eax), "b"((long)ebx)
//            : "1"
            );

    printf("ebx=%ld\n", ebx);
    return 0;
}
