#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main()
{
    char str[256];
    int ret = 0;
    
    FILE *fp = fopen("igfx_registry.txt_dump", "r");
    if(!fp){
        printf("%s: %s\n", "Cannot open the file", "igfx_registry.txt_dump");
    }

    memset(str, 0x00, 256);
    do
    {
        memset(str, 0x00, 256);
        ret = fscanf(fp, "%255[^\n]\n", str);
        printf("ret=%d:%s\n", ret, str);
    }while( ret  > 0);

    fclose(fp);
}
