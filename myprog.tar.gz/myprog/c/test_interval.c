#include <stdio.h>
#include <stdlib.h>
#include <sys/time.h>

#if 0
struct timeval {
    time_t      tv_sec;     /* seconds */
    suseconds_t tv_usec;    /* microseconds */
};
#endif 

int main()
{
    struct timeval begin = {
        .tv_sec = 0,
        .tv_usec = 0};
    struct timeval end = begin;

    gettimeofday(&begin, NULL);
    printf("tv_sec %ld tv_use %ld\n", begin.tv_sec, begin.tv_usec);
    int i = 0;
    for(i = 1; i <10000; )
    {
        i++;
    }
    gettimeofday(&end, NULL);
    printf("tv_sec %ld tv_use %ld\n", end.tv_sec, end.tv_usec);

}
