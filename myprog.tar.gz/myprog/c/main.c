/*
 * =====================================================================================
 *
 *       Filename:  main.c
 *
 *    Description:  
 *
 *        Version:  1.0
 *        Created:  05/21/2012 05:07:00 PM
 *       Revision:  none
 *       Compiler:  gcc
 *
 *         Author:  YOUR NAME (), 
 *   Organization:  
 *
 * =====================================================================================
 */
#include "main.h"
#include "define.h"

#include <stdio.h>
#include <stdlib.h>

//#define LOGE printf
//#define CHECK_CONTIDION(condition,str,ret) \
//    if((condition)){\
//        LOGE("%s: %s\n", __FUNCTION__, (str));\
//        return ret;\
//    }
//#define CHECK_NULL(p,str, ret) CHECK_CONTIDION(NULL==(p),str,ret)
//#define CHECK_NULL(p,str, ret) \
//    if(NULL == (p)){\
//        LOGE("%s: %s\n", __FUNCTION__, (str));\
//        return ret;\
//    }


int main(){

#ifdef DEBUG
    {
        printf("The DEBUG is Defined!\n");
    }
#endif
    char * p = NULL;
    char *tmpStr = (char *)malloc(6*sizeof(char));
    int i = 5;

//CHECK_CONTIDION(i<10,"i<10", 5) 
//CHECK_NULL(p, "NULL pointer",)
    printf("%s %d %s\n", __FILE__, __LINE__, __FUNCTION__);
CHECK_NULL(p, "NULL pointer", 2);

    return 0;
}

