#if 0
	{
			char filename[128];
			int dump_fd = -1;
			int nloop =0;
			char temp[128];
                        static int nIndex = 0;
			nIndex++;
			memset(filename,0,128);
			DWORD *pcur =  pCmdBuffer->pCmdBase;
			sprintf(filename,"/home/liuth/work/gpuhung/dump_cmd.txt");
			
			if ((dump_fd = open(filename, O_CREAT | O_RDWR | O_SYNC | O_APPEND, 0777)) < 0) {
				printf("error open file:");
				return -1;
			}
			lseek(dump_fd, 0, SEEK_END);
			sprintf(temp,"DMA_SIZE: %d\n",CmdBufferSize/4);
			write(dump_fd,temp,strlen(temp));
			for(nloop=0;nloop<CmdBufferSize;){
				memset(temp,0,128);
				sprintf(temp,"DMA_CMD: %08x\n",*pcur);
				write(dump_fd,temp,strlen(temp));
				pcur++;
				nloop+=4;
			}
			printf("Save decompressed file into %s\n",filename);
			close(dump_fd);
	}
#endif   
