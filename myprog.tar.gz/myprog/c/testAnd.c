/*
 * =====================================================================================
 *
 *       Filename:  testAnd.c
 *
 *    Description:  
 *
 *        Version:  1.0
 *        Created:  06/29/2012 10:41:09 AM
 *       Revision:  none
 *       Compiler:  gcc
 *
 *         Author:  YOUR NAME (), 
 *   Organization:  
 *
 * =====================================================================================
 */
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
int main()
{
 typedef struct {
     int * a;
     int b;
 }TEST;
    int b = 6;
    int a = 5;
//    if(a != 1 || a  != 2 || a != 3){
//        printf("|| True\n");
//    }

//    if(a != 1 && a  != 2 && a != 3){
//        printf("&& True\n");
//    }

    TEST *test = malloc(sizeof(TEST));
    memset(test, 0x00, sizeof(TEST));
    if(test != NULL && test->a != NULL){
        printf("1111111111\n");
    }
    else{
        printf("22222\n");
    }
    
int number = 0x5678;
    printf("%#.8x\n", number);
return 0;
}

