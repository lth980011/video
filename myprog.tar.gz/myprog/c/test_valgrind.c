#include <string.h>
#include <stdlib.h>

int main()
{
    unsigned int size = sizeof(char)*6;
    unsigned char * pStr = (unsigned char *)malloc(size);
    memset(pStr, 0x00, size);
    pStr[size] = 0x61;
    
    free(pStr);

    return 0;
}
