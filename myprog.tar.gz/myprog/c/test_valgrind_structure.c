#include <string.h>
#include <stdlib.h>

typedef struct _test_struct
{
    int a;
    int b;
    unsigned char * gsh
}TEST_STRUCT;
typedef struct _test_gsh
{
    int a;
    int b;
    TEST_STRUCT *gsh;
}TEST_GSH;

int main()
{
    unsigned int size = sizeof(int)*6;
    int *p = (int *)malloc(size);
    unsigned char * tmp = (unsigned char *)p;

    tmp+=4;
    memset(tmp, 0x00, size-4);
    free(p);

    TEST_GSH *gsh = malloc(sizeof(TEST_GSH));
    gsh->gsh = malloc(sizeof(TEST_STRUCT));
    unsigned char *pdata = gsh->gsh;
    memset(pdata, 0x00, 4);

    return 0;
}
