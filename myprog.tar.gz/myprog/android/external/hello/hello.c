#include <stdlib.h>

int main()
{
    printf("Hello world!\n");
    int i;
    i++;
    
    return 0;
}
