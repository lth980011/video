#include <fstream>

int main()
{
    char filePath[256] = "1.cpp";
    new std::ofstream(filePath, ios::app);

}
