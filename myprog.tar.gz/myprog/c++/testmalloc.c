#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>

int main()
{
    int size = 649856;
    //void * pData = (void *)(0x7ffff7ff7000);
    char * pData = (char *)malloc(649856);
    //memset(pData, 0x0, size);
    pData[649855]='a';
    pData = (char *)( 0x7ffff7f42010);
   // memset(pData, 0x0, size);
    sleep(1000);
    pData[649855]='b';
//pData = (char *)(0x7ffff7ff7000);
//    memset(pData, 0x0, size);
//    pData[649855]='c';
    return 0;
}
