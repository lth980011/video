#include <cstdio>
#include <cstdlib>
typedef struct {
   int class;
}TEST;

int main()
{
    TEST test;
    TEST *ptest = &test;
    return 0;
}
