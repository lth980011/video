#include <cstdlib>
#include <cstdio>
#include <iostream>

int main()
{
    // pointer to const object
    const double *cptr=NULL; // initialize as 0 NULL, meaningless.
    //*cptr=12;//error
    const double pi=3.14;
    cptr = &pi;// 
    //double *ptr = &pi;//error
    const double *pdtr=&pi;//ok

    const int universe = 5;
    const void *cpv=&universe;
    //void * pv = &universe; //error

    double dval=3.14159; //dval is not const
    cptr = &dval;
    std::cout<<"const double *cptr="<<*cptr<<std::endl;
    dval =6;
    std::cout<<"const double *cptr="<<*cptr<<std::endl;

    //*cptr=3.14159; //error:cptr is a pointer to const
    double *ptr=&dval; //ok:ptr points at non-const double
    *ptr=2.72;        //ok:ptr is plain pointer
    std::cout<<"const double *cptr="<<*cptr<<std::endl;      //ok:prints 2.72

    // const pointer
    int errNumb=0;
    int *const curErr=&errNumb; //curErr is a constant pointer
    //curErr=&errNumb;   //error: curErr is const
    //curErr=curErr;   //error: curErr is const
    
    *curErr =1;

    typedef int * pint;
    const pint pcNum = &errNumb;// const pointer must be initialized.

}
