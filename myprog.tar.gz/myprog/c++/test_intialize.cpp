#include <stdio.h> 
int main() 
{ 
    printf("请输入一个数字: "); 
    int t; 
    scanf("%d", &t); 
    switch (t) 
    { 
        case 0: 
            int a ; 
            printf("/n a = %d/n",  0); 
            break; 
        case 1: 
            printf("/n a = %d/n",  1); 
            break; 
        default: 
            printf("/n a = %d/n",  t); 
            break; 
    } 
}
