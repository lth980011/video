#!/bin/sh

for x in $*
do
    echo $x
done
