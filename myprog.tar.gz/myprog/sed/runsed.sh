#!/bin/sh

sedscr=$1
for fileName  in $*
do 
    echo "editing $fileName: \c"
    if test "$fileName" = $sedscr; then
        echo "not editing sedscript!"
    elif test -s $fileName; then
        sed -f $sedscr $fileName > /tmp/$fileName$$
        if test -s /tmp/$fileName$$
        then
            if cmp -s $fileName /tmp/$fileName$$
            then 
                echo "file not changed: \c"
            else
                mv $fileName $fileName.bak #save original, just in case
                cp /tmp/$fileName$$ $fileName
            fi
            echo "done"
        else
            echo "Sed produced an empty file \c"
            echo "-check your sedscript."
        fi
        rm -f /tmp/$fileName$$
    else 
        echo "original file is empty."
    fi
done
echo "all done"
