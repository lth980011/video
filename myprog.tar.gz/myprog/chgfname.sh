#!/bin/bash

ALL_FILE=`ls`
for file in $ALL_FILE
do
    tmp_file=`echo $file |sed -n 's/..*\[\(preALL\)\]..*\(_f[[0-9][0-9]*..*\)/\1\2/p'`
    if [[ -n $tmp_file ]]; then
        echo aaaaaaaaa
       mv $file $tmp_file
    fi
    tmp_file=`echo $file |sed -n 's/..*\[\(postALL\)\]..*\(_f[[0-9][0-9]*..*\)/\1\2/p'`
    if [[ -n $tmp_file ]]; then
        echo ---------
       mv $file $tmp_file
    fi
done
