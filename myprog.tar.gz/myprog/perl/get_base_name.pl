#!/usr/bin/perl 
use feature 'say';

use File::Basename;
my $file_name = "/home/liuth/1.sh";
my $base_name = fileparse($file_name, qr/\.[^.]*/) . "_scaling.nv12";
say $base_name;
