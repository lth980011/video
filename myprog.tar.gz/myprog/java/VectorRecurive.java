Vetor<String> tmpStr = makeRules(allParm, allParm.size()-1);
// recursive 
Vector<String> makeRules(Vector<Vector<String>> allParm,
   int index) {
     String separator = System.getProperty("line.separator");
  Vector<String> tmpStp = new Vector<String>();
  Vector<String> firStp = null;
  if (index == 0) {
   firStp = allParm.get(index);
   return firStp;
  }
  firStp = makeRules(allParm, index-1);
  Vector<String> secStp = allParm.get(index);
  for (String firLine : firStp) {
   for (String secLine : secStp) {
    tmpStp.add(firLine + separator + secLine);
   }
  }
  return tmpStp;
 }
