class HelloWorld{
	public static void main(String[] args){
         String tmp ="12345567"; 
         String [] str = tmp.split("a");
         System.out.println(""+str.length);
         System.out.println(str);
	}
}
