#include <stdio.h>
#include <stdlib.h>

int main()
{
    unsigned long long count = 0xFFFFFFFFFFFFFFFF;
    const int MAX_PATH = 128;
    printf("sizeof count=[%ld]\n", sizeof(count));
    printf("sizeof count=[%ld]\n", sizeof(long long));
    printf("%s_f[%03llu]_w[%d]_h[%d]_p[%d].%s\n",
            "a", count, 2,3,4,"b");
    printf("%s_f[%03llx]_w[%d]_h[%d]_p[%d].%s\n",
            "a", count, 2,3,4,"b");
    printf("%s_f[%03I64d]_w[%d]_h[%d]_p[%d].%s\n",
            "a", count, 2,3,4,"b");


//    _snprintf_s(
//            sPath, 
//            MAX_PATH,
//            sizeof(sPath),
//            "%s_f[%03I64d]_w[%d]_h[%d]_p[%d].%s",
//            psPathPrefix,
//            iCounter,
//            pSurface->dwWidth,
//            pSurface->dwHeight,
//            pSurface->dwPitch,
//            VpHalDbg_GetFormatStr(pSurface->Format));
}
