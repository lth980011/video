/* config.h.  Generated from config.h.in by configure.  */
/* config.h.in.  Generated from configure.in by autoheader.  */

/* Name of package */
#define PACKAGE "main"

/* Define to the address where bug reports for this package should be sent. */
#define PACKAGE_BUGREPORT "lth980010@gamil.com"

/* Define to the full name of this package. */
#define PACKAGE_NAME "main"

/* Define to the full name and version of this package. */
#define PACKAGE_STRING "main 1.0"

/* Define to the one symbol short name of this package. */
#define PACKAGE_TARNAME "main"

/* Define to the home page for this package. */
#define PACKAGE_URL ""

/* Define to the version of this package. */
#define PACKAGE_VERSION "1.0"

/* Version number of package */
#define VERSION "1.0"
